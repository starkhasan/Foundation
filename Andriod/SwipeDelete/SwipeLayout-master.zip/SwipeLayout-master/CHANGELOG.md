# Change Log

Version 1.0.8 *(2018-10-16)*
Added commands to perform a swipe without animation.


Version 1.0.9 *(2019-02-26)*
The root package has been renamed.


Version 1.0.10 *(2019-05-10)*
Added ability to disable swipe.


Version 1.0.11 *(2019-09-27)*
Added ability to intercept touch


Version 1.1.1 *(2019-09-27)*
Migrate to Android X


Version 1.3.0 *(2019-11-28)*
Migrate to zerobranch
